Funzionalità realizzate: tutte quelle presenti nella specifica. Non sono state sviluppate funzionalità extra.

Dipendenze necessarie:

    1 - Lato server: 
        1 - Jakarta servlet API
        2 - Jakarta servlet jsp API
        3 - Jakarta el API
        4 - Jakarta websocket API
        5 - Jakarta authentication API
        6 - Jersey container servlet
        7 - Jersey hk2
        8 - Jackson jakarta json provider
        9 - jjwt Jackson
        10 - jjwt impl
        11 - javafaker 

    2 - Lato client: nessuna.    

Il progetto è stato completamente sviluppato in pair programming per cui il contributo effettivo al progetto dei due elementi del team è sostanzialmente analogo e ricopre l'intero progetto.